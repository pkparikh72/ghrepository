# This repo is no longer used. Please see  https://github.com/microsoft/devops-project-samples for samples of Azure DevOps Project

| Language | Platform | Author |
| -------- | --------|--------|
| HTML |  Azure Web App, Virtual Machine| |

# Sample HTML website 

Sample HTML/CSS web app that you can deploy to Azure. 

## License

See [LICENSE](LICENSE).


## Contributing
This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

